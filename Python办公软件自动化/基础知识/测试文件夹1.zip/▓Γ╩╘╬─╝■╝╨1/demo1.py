# 书写人：胡高远
# 书写时间：2022/7/14  9:49
print('Hello world')